Template dokumen Proposal Tugas Akhir untuk mata kuliah II4091 Proposal Tugas Akhir
Program Studi Sistem dan Teknologi Informasi
Institut Teknologi Bandung

Dokumen utama:
1. ProposalTA.tex
2. daftar-pustaka.bib

by baskara at itb dot ac dot id
